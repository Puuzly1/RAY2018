# RAY2018
**Nombre:** Lydia Fernández García   
**Edad:** 18 años  
**Ciclo formativo:** Animacion 3D, desarrollo de juevos y entornos interactivos.  
**Ejercicio para:**  Realizacion de proyectos multimedia interactivos (Ray)  
Ejercicios:
===========


